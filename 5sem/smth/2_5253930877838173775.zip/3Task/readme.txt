g++ main.cpp matrix.cpp -o prog

g++ main.cpp matrix.cpp vector.cpp -o prog

out.txt 10
out.txt 3 in.txt

1 1.73282 -2.02513 1.37702
1 3.70332 -1.29853 2.14459
2 5.24799 -0.341362 3.78709
2 4.12228 -0.0941667 7.74583

2 1 3 4
1 -3 1 5
3 1 6 -2
4 5 -2 -2

1 2 3
4 5 6
7 8 10

x 0xfa3dc0
tmp 0xfa3d00
e 0xdd3d40

&& (fabs(fabs(a[n-k-1][n-k-2])-fabs(pr)) > eps)

0x704320 x*x

