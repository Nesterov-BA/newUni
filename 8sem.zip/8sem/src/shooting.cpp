#include "rungeKutta.hpp"
#include <cmath>
#include <cstdio>
#include <iterator>
#include <vector>

double derivative(double x, double (*func)(double))
{
    double res;
    double eps = 1.e-7;
    res = func(x + eps) - func(x);
    printf("\n fun = %.12lf\n", func(x+eps));
    printf(" x + eps = %.12lf\n", x+eps);
    res /= eps;
    return res;
}
void probe(double* start, double (*function)(double))
{
    FILE* minimumStarts = fopen("starts.csv", "w");
    fprintf(minimumStarts, "p2,x1,alpha\n");
    while(alpha < 10.5)
    {
        printf("alpha = %lf\n", alpha);
        printf("Start = %lf\n", *start);
        if(findMinimum(start, function) < 0)
        {
            printf("something wrong!\n");
            break;
        }
        printf("Val = %.10lf\n", function(*start));
        printf("Start = %lf\n\n", *start);
        alpha +=1;
    }


}

int findMinimum(double* start, double (*function)(double))
{
    double tempStart = *start;
    double deriv;
    double res = 1;
    double coefficent = 1;
    int count = 0;
    while(fabs(res) > 1.e-7)
    {
        count++;
        deriv = derivative(tempStart, function);
        res = function(tempStart);
        while(fabs(function(tempStart - coefficent*res/deriv)) > fabs(function(tempStart)))
        {
            if(coefficent < 1.e-11)
            {
                printf("Small coefficent!\n");
                return -1;
            }
        }
        tempStart -= coefficent*res/deriv;
        if(count > 50)
        {
            printf("Big Count!\n");
            return -1;
        }
    }
    *start = tempStart;
    return 0;
}
