#include "metricFuncs.hpp"
#include "graph.hpp"
#include "errors.hpp"
// #include "normCalculation.hpp"
#include <cstdio>
#include <iostream>
#include <vector>

double dx1(double x1, double x2);
double dx2(double x1, double x2);
double errorFunc(double x2);

double dx1(double x1, double x2)
{
    x1 = x1;
    return x2;
}
double dx2(double x1, double x2)
{
    x2 = x2;
    return alpha*x1*x1*sin(alpha*x1) - x1*cos(alpha*x1);
}
function functions[] =
    {
        dx1,
        dx2
    };

double errorFunc(double x2)
{
    double result = error(x2, functions, alpha);
    return result;
}

int main()
{
    finish = pi;
    double start[2] = {0, 1};
    double end[2];
    double globalError;
    tolerance = 1.e-11;
    alpha = 0;
    findMinimum(&start[1], errorFunc);
    printf("\nStart:0, %lf\n", start[1]);
    printf("End: %.e\n", errorFunc(start[1]));
    globalError = 0;
    solutionUpToTime(start, end, functions, pi, &globalError);
    printf("Alpha = %lf, err = %.e\n", alpha, globalError);
    start[1] = 1;
    alpha = 0.1;
    findMinimum(&start[1], errorFunc);
    printf("\nStart:0, %lf\n", start[1]);
    printf("End: %.e\n", errorFunc(start[1]));
    globalError = 0;
    solutionUpToTime(start, end, functions, pi, &globalError);
    printf("Alpha = %lf, err = %.e\n", alpha, globalError);
    start[1] = 1;
    alpha = 0.5;
    findMinimum(&start[1], errorFunc);
    printf("\nStart:0, %lf\n", start[1]);
    printf("End: %.e\n", errorFunc(start[1]));
    globalError = 0;
    solutionUpToTime(start, end, functions, pi, &globalError);
    printf("Alpha = %lf, err = %.e\n", alpha, globalError);
    start[1] = 1;
    alpha = 1.5;
    findMinimum(&start[1], errorFunc);
    printf("\nStart:0, %lf\n", start[1]);
    printf("End: %.e\n", errorFunc(start[1]));
    globalError = 0;
    solutionUpToTime(start, end, functions, pi, &globalError);
    printf("Alpha = %lf, err = %.e\n", alpha, globalError);
    start[1] = 1.8;
    alpha = 10.5;
    findMinimum(&start[1], errorFunc);
    printf("\nStart:0, %.20lf\n", start[1]);
    printf("End: %.e\n", errorFunc(start[1]));
    globalError = 0;
    solutionUpToTime(start, end, functions, pi, &globalError);
    printf("Alpha = %lf, err = %.e\n", alpha, globalError);
//    probe(&start[1], errorFunc);
    double bounds[2] = {0, 5};
//    graph("errorGraph.csv", errorFunc, bounds);
    return 0;
}
