#include "errors.hpp"

double error(double x2, function* functions, double alpha)
{
    double start[2] = {0, x2};
    double end[2];
    double res;
    double finish = pi;
    solutionUpToTime(start, end, functions, finish);
    alpha = alpha;
    res = end[0] - 1;
    return res;
}
