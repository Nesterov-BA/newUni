#include <bits/types/FILE.h>
#include <fstream>
#include <vector>
#include <iostream>
#include "math.h"
#include <cstdio>
inline double tolerance;
inline double alpha;
inline double finish;
typedef double (*function)(double, double);
const double pi = 3.1415/2;

using namespace std;
