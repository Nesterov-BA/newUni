#include "rungeKutta.hpp"

double error(double x2, function* functions, double alpha);
