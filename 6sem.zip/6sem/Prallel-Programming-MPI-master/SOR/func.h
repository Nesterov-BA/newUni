double func(double x,double y)
{
return sin(x)+y;
}
