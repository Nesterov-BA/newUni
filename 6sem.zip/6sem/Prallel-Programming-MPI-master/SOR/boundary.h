double boundary(double x,double y)
{
return x+y;
}
