double g(double x,double y)
{
return (1 + x)*sin(x + y);
}
