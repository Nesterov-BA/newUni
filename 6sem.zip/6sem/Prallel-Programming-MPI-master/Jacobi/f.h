double f(double x,double y)
{
return 2*((1+x)*sin(x+y)-cos(x+y));
}
