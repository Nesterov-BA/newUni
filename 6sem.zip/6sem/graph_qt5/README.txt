download qt5

1d 18 42 

2d 

mpi  то же самое (невязка)

