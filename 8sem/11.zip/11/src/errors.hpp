#include "rungeKutta.hpp"

std::vector<double> error(double p1, double p2, function* functions);
