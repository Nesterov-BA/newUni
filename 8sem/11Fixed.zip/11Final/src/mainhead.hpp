#include <bits/types/FILE.h>
#include <fstream>
#include <vector>
#include <iostream>
#include "math.h"
#include <cstdio>

extern double tolerance;
extern double alpha;
extern double finish;

typedef double (*function)(double, double, double, double, double);

using namespace std;
