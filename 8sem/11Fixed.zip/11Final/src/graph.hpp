#include <cstdio>
#include <iostream>
#include <string>

void graph(std::string filename, double func(double, double), double* bounds);
