#include <stdio.h>
#include <iostream>
#include <cmath>

double f0(double x   );
double f1(double x   );
double f2(double x   );
double f3(double x   );
double f4(double x   );
double f5(double x   );
double f6(double x   );
double f7(double x   );
double d2f0(double x  );
double d2f1(double x  );
double d2f2(double x  );
double d2f3(double x  );
double d2f4(double x  );
double d2f5(double x  );
double d2f6(double x  );
double d2f7(double x  );
double max_matr(double *M, int size);
double min_matr(double *M, int size);
double max4(double a, double b, double c, double d);
double min4(double a, double b, double c, double d);
double max(double a, double b);
double min(double a, double b);
double diffFun2(double val1, double val2, double x1, double x2);
